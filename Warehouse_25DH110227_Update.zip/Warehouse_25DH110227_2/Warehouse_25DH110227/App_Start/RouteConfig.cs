﻿using System.Web.Mvc;
using System.Web.Routing;
namespace Warehouse_25DH110227
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            routes.MapRoute("Default", "{controller}/{action}/{id}",
                new { controller = "Products", action = "Index", id = UrlParameter.Optional });
        }
    }
}
