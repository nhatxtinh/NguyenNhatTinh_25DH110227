﻿# Chạy sau khi sửa hoặc Update Model from Database trong EDMX.
$ErrorActionPreference = 'Stop'
$baseDir = Join-Path $PSScriptRoot 'Warehouse_25DH110227\Models'
[xml]$model = Get-Content (Join-Path $baseDir 'WarehouseModel.edmx') -Raw
$ns = New-Object System.Xml.XmlNamespaceManager($model.NameTable)
$ns.AddNamespace('e', 'http://schemas.microsoft.com/ado/2009/11/edmx')
$sections = @{ConceptualModels='csdl'; StorageModels='ssdl'; Mappings='msl'}
foreach ($section in $sections.Keys) {
    $node = $model.SelectSingleNode("/e:Edmx/e:Runtime/e:$section/*", $ns)
    $doc = New-Object System.Xml.XmlDocument
    [void]$doc.AppendChild($doc.ImportNode($node, $true))
    $doc.Save((Join-Path $baseDir ('WarehouseModel.' + $sections[$section])))
}
Write-Host 'Da dong bo 3 tai nguyen EDMX. Hay Rebuild Solution.'
